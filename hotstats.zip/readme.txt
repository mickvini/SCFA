See:
http://forums.gaspowered.com/viewtopic.php?t=26544

This mod enhances the score screen by graphs 
and charts. It is UI only and has no dependencies. 

This was once part of the famous SCA UI mod by
Cleopatre, Goom and Saya.
Zulan has ported it to FA with friendly permission.


Installation:

Just place the zip file into your 
%USERPROFILE%\My Documents\My Games\Gas Powered Games\Supreme Commander Forged Alliance\Mod
Path. Do notunzip it.
