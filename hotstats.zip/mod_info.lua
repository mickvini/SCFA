name = "Hotstats"
uid = "175542E4-D4F5-11DC-B450-11D755D89593"
version = 4
description = "Enhances the score screen. This was part of the SCA UI mod by Saya and ported to FA by Zulan."
author = "Zulan"
url = "http://forums.gaspowered.com/viewtopic.php?p=372596"
icon = "/mods/hotstats/mod_icon.dds"
selectable = true
enabled = true
exclusive = false
ui_only = true
requires = { }
requiresNames = { }
conflicts = { }
before = {  }
after = { }